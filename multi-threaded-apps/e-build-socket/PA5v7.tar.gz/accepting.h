/***
CS361
PA3 - e-buld
Authors: Cole Bradley, Pavan Gudimetta
***/

#ifndef accepting_h
#define accepting_h

#include "state.h"

//Declare all functions performed when in the closing state
static state_t* order_received();
static void entry_to();

#endif
